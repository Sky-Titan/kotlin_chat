package org.techtown.kotlinchat

import android.app.Application

class MyApplication : Application (){

    lateinit var user_ID : String

    override fun onCreate() {
        super.onCreate()
    }

    companion object{
        lateinit var INSTANCE : MyApplication
    }
}